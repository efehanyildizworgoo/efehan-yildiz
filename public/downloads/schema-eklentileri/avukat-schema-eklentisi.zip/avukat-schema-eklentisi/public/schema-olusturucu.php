<?php
/**
 * Sitenin ön yüzünde gerekli schema verilerini oluşturur ve <head> etiketine ekler.
 *
 * @package AvukatSchema\Public
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class AvukatSchemaPublic {

    private $options;

    public function __construct() {
        $this->options = get_option( 'avukat_schema_options' );
        add_action( 'wp_head', array( $this, 'inject_schema' ) );
    }

    public function inject_schema() {
        $schema = array();

        if ( is_front_page() ) {
            $schema = $this->generate_homepage_schema();
        } elseif ( is_singular( 'post' ) ) {
            $schema = $this->generate_blog_schema();
        } elseif ( is_page() && isset($this->options['hizmet_sayfalari']) && in_array(get_the_ID(), (array)$this->options['hizmet_sayfalari']) ) {
            $schema = $this->generate_service_schema();
        }

        if ( ! empty( $schema ) ) {
            echo '<script type="application/ld+json">' . json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>';
        }
    }

    private function generate_homepage_schema() {
        if ( empty( $this->options['firma_adi'] ) ) {
            return array();
        }

        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'LegalService',
            'name'        => $this->options['firma_adi'],
            'url'         => get_home_url(),
            'telephone'   => isset( $this->options['telefon'] ) ? $this->options['telefon'] : '',
            'description' => isset( $this->options['aciklama'] ) ? $this->options['aciklama'] : get_bloginfo('description'),
        );
        
        if ( ! empty( $this->options['logo_url'] ) ) {
            $schema['logo'] = $this->options['logo_url'];
            $schema['image'] = $this->options['logo_url'];
        }

        if ( ! empty( $this->options['adres'] ) ) {
            $schema['address'] = array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => $this->options['adres'],
            );
        }

        if ( ! empty( $this->options['calisma_saatleri'] ) ) {
            $opening_hours = array();
            foreach ($this->options['calisma_saatleri'] as $day => $hours) {
                if (!empty($hours)) {
                    list($opens, $closes) = explode('-', $hours);
                    $opening_hours[] = array(
                        '@type'     => 'OpeningHoursSpecification',
                        'dayOfWeek' => 'https://schema.org/' . $day,
                        'opens'     => trim($opens),
                        'closes'    => trim($closes)
                    );
                }
            }
            if(!empty($opening_hours)){
                $schema['openingHoursSpecification'] = $opening_hours;
            }
        }
        
        return $schema;
    }

    private function generate_blog_schema() {
        global $post;
        $author_id = $post->post_author;

        $schema = array(
            '@context'       => 'https://schema.org',
            '@type'          => 'BlogPosting',
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id'   => get_permalink(),
            ),
            'headline'       => get_the_title(),
            'datePublished'  => get_the_date('c'),
            'dateModified'   => get_the_modified_date('c'),
            'author'         => array(
                '@type' => 'Person',
                'name'  => get_the_author_meta( 'display_name', $author_id ),
            ),
            'publisher'      => array(
                '@type' => 'Organization',
                'name'  => isset( $this->options['firma_adi'] ) ? $this->options['firma_adi'] : get_bloginfo('name'),
                'logo'  => array(
                    '@type' => 'ImageObject',
                    'url'   => isset( $this->options['logo_url'] ) ? $this->options['logo_url'] : '',
                ),
            ),
            'description'    => get_the_excerpt(),
        );

        if ( has_post_thumbnail() ) {
            $schema['image'] = get_the_post_thumbnail_url();
        }

        return $schema;
    }

    private function generate_service_schema() {
        global $post;
        
        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Service',
            'name'        => get_the_title(),
            'description' => get_the_excerpt(),
            'provider'    => array(
                '@type' => 'LegalService',
                'name'  => isset( $this->options['firma_adi'] ) ? $this->options['firma_adi'] : get_bloginfo('name'),
                'url'   => get_home_url(),
            ),
        );
        
        // Hizmetin sunulduğu bölge bilgisi de eklenebilir, ancak bu genellikle ana firma schemasında yer alır.
        // 'areaServed' => ...

        return $schema;
    }
}
?>