<?php
/**
 * Plugin Name:       Hukuk Schema Eklentisi
 * Description:       Avukatlık ve hukuk büroları için özelleştirilmiş Schema.org JSON-LD yapılarını WordPress sitelerine entegre eder. Ana sayfa, hizmetler ve blog yazıları için otomatik schema oluşturur.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        hhttp://worgoo.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       avukat-schema
 *
 * @package           AvukatSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'AVUKAT_SCHEMA_VERSION', '1.0.0' );
define( 'AVUKAT_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once AVUKAT_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once AVUKAT_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'AvukatSchemaAdmin' ) ) {
    new AvukatSchemaAdmin();
}

if ( class_exists( 'AvukatSchemaPublic' ) ) {
    new AvukatSchemaPublic();
}

?>
