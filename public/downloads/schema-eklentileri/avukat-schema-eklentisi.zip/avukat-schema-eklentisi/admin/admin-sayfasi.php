<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package AvukatSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class AvukatSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        // WordPress Ayarlar menüsü altına yeni bir sayfa ekler
        add_options_page(
            'Avukat Schema Ayarları',
            'Avukat Schema',
            'manage_options',
            'avukat-schema-ayarlari',
            array( $this, 'create_admin_page' )
        );
    }

    public function create_admin_page() {
        $this->options = get_option( 'avukat_schema_options' );
        ?>
        <div class="wrap">
            <h1>Avukat Schema Ayarları</h1>
            <p>Bu sayfadan hukuk büronuzun schema bilgilerini yönetebilirsiniz. Bilgileri eksiksiz doldurmanız, arama motorlarında daha iyi sonuçlar almanıza yardımcı olacaktır.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'avukat_schema_option_group' );
                do_settings_sections( 'avukat-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting(
            'avukat_schema_option_group',
            'avukat_schema_options',
            array( $this, 'sanitize' )
        );

        // Ana Sayfa Schema Ayarları Bölümü
        add_settings_section(
            'setting_section_homepage',
            'Ana Sayfa Schema Ayarları (LawFirm)',
            array( $this, 'print_section_info' ),
            'avukat-schema-admin'
        );

        add_settings_field( 'firma_adi', 'Hukuk Bürosu Adı', array( $this, 'firma_adi_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        add_settings_field( 'telefon', 'Telefon Numarası', array( $this, 'telefon_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        add_settings_field( 'logo_url', 'Logo URL Adresi', array( $this, 'logo_url_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        add_settings_field( 'adres', 'Açık Adres', array( $this, 'adres_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        add_settings_field( 'aciklama', 'Firma Açıklaması', array( $this, 'aciklama_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        add_settings_field( 'calisma_saatleri', 'Çalışma Saatleri', array( $this, 'calisma_saatleri_callback' ), 'avukat-schema-admin', 'setting_section_homepage' );
        
        // Hizmet Sayfaları Schema Ayarları Bölümü
        add_settings_section(
            'setting_section_services',
            'Hizmet Sayfaları Schema Ayarları (Service)',
            array( $this, 'print_service_section_info' ),
            'avukat-schema-admin'
        );

        add_settings_field( 'hizmet_sayfalari', 'Hizmet Sayfalarını Seçin', array( $this, 'hizmet_sayfalari_callback' ), 'avukat-schema-admin', 'setting_section_services' );
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['firma_adi'] ) ) $new_input['firma_adi'] = sanitize_text_field( $input['firma_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );

        if(isset($input['calisma_saatleri'])){
            $new_input['calisma_saatleri'] = array_map('sanitize_text_field', $input['calisma_saatleri']);
        }

        if ( isset( $input['hizmet_sayfalari'] ) ) {
            $new_input['hizmet_sayfalari'] = array_map( 'absint', (array) $input['hizmet_sayfalari'] );
        }

        return $new_input;
    }

    public function print_section_info() {
        echo 'Sitenizin ana sayfası için Hukuk Bürosu (LawFirm) schema bilgilerini girin.';
    }

    public function print_service_section_info() {
        echo 'Hizmet verdiğiniz alanları tanıttığınız sayfaları seçin. Bu sayfalara otomatik olarak "Service" schema yapısı eklenecektir.';
    }

    // Callback fonksiyonları (form elemanlarını oluşturur)
    public function firma_adi_callback() { printf( '<input type="text" id="firma_adi" name="avukat_schema_options[firma_adi]" value="%s" class="regular-text" />', isset( $this->options['firma_adi'] ) ? esc_attr( $this->options['firma_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" id="telefon" name="avukat_schema_options[telefon]" value="%s" class="regular-text" placeholder="+905551234567"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" id="logo_url" name="avukat_schema_options[logo_url]" value="%s" class="regular-text" placeholder="https://example.com/logo.png" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea id="adres" name="avukat_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea id="aciklama" name="avukat_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }

    public function calisma_saatleri_callback() {
        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $days_tr = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

        echo '<p class="description">Çalışma saatlerini 24 saat formatında girin (örn: 09:00-18:00). Boş bırakılan günler schema\'ya eklenmez.</p>';
        
        foreach ($days as $index => $day) {
            $value = isset($this->options['calisma_saatleri'][$day]) ? esc_attr($this->options['calisma_saatleri'][$day]) : '';
            printf(
                '<div style="margin-bottom: 5px;"><label style="width: 100px; display: inline-block;">%s:</label> <input type="text" name="avukat_schema_options[calisma_saatleri][%s]" value="%s" placeholder="09:00-18:00" /></div>',
                $days_tr[$index], $day, $value
            );
        }
    }
    
    public function hizmet_sayfalari_callback() {
        $selected_pages = isset($this->options['hizmet_sayfalari']) ? (array) $this->options['hizmet_sayfalari'] : [];
        $pages = get_pages();
        
        if ($pages) {
            echo '<select id="hizmet_sayfalari" name="avukat_schema_options[hizmet_sayfalari][]" multiple="multiple" style="min-height: 150px; min-width: 300px;">';
            foreach ($pages as $page) {
                $selected = in_array($page->ID, $selected_pages) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select>';
            echo '<p class="description">Birden fazla sayfa seçmek için CTRL (Windows) veya Command (Mac) tuşuna basılı tutun.</p>';
        } else {
            echo '<p>Sitenizde henüz hiç sayfa oluşturulmamış.</p>';
        }
    }
}
?>
