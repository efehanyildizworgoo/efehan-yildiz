<?php
/**
 * Plugin Name:       Kardiyolog Schema Eklentisi
 * Description:       Kardiyologlar için Physician ve MedicalClinic schema yapılarını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kardiyolog-schema
 *
 * @package           KardiyologSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'KARDIYOLOG_SCHEMA_VERSION', '1.0.0' );
define( 'KARDIYOLOG_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once KARDIYOLOG_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once KARDIYOLOG_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'KardiyologSchemaAdmin' ) ) {
    new KardiyologSchemaAdmin();
}

if ( class_exists( 'KardiyologSchemaPublic' ) ) {
    new KardiyologSchemaPublic();
}
?>
