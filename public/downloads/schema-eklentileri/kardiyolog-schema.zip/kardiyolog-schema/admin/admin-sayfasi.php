<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package KardiyologSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class KardiyologSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('Kardiyolog Schema Ayarları', 'Kardiyolog Schema', 'manage_options', 'kardiyolog-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'kardiyolog_schema_options' );
        ?>
        <div class="wrap">
            <h1>Kardiyolog Schema Ayarları</h1>
            <p>Doktor ve muayenehane için schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'kardiyolog_schema_option_group' );
                do_settings_sections( 'kardiyolog-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('kardiyolog_schema_option_group', 'kardiyolog_schema_options', array( $this, 'sanitize' ));

        // Muayenehane Bilgileri
        add_settings_section('setting_section_main', 'Doktor ve Muayenehane Bilgileri', null, 'kardiyolog-schema-admin');
        add_settings_field('hekim_adi', 'Hekim Adı', array( $this, 'hekim_adi_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');
        add_settings_field('klinik_adi', 'Klinik / Muayenehane Adı', array( $this, 'klinik_adi_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres (Samsun)', array( $this, 'adres_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'Klinik Açıklaması', array( $this, 'aciklama_callback' ), 'kardiyolog-schema-admin', 'setting_section_main');

        // Sayfa Seçimleri
        add_settings_section('setting_section_pages', 'Hizmet Sayfaları', null, 'kardiyolog-schema-admin');
        add_settings_field('hizmet_sayfalari', 'Tedavi / Hizmet Sayfaları', array( $this, 'hizmet_sayfalari_callback' ), 'kardiyolog-schema-admin', 'setting_section_pages');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['hekim_adi'] ) ) $new_input['hekim_adi'] = sanitize_text_field( $input['hekim_adi'] );
        if ( isset( $input['klinik_adi'] ) ) $new_input['klinik_adi'] = sanitize_text_field( $input['klinik_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );

        if ( isset( $input['hizmet_sayfalari'] ) && is_array( $input['hizmet_sayfalari'] ) ) {
            $new_input['hizmet_sayfalari'] = array_map( 'absint', $input['hizmet_sayfalari'] );
        }

        return $new_input;
    }

    // Callbacks
    public function hekim_adi_callback() { printf( '<input type="text" name="kardiyolog_schema_options[hekim_adi]" value="%s" class="regular-text" />', isset( $this->options['hekim_adi'] ) ? esc_attr( $this->options['hekim_adi'] ) : '' ); }
    public function klinik_adi_callback() { printf( '<input type="text" name="kardiyolog_schema_options[klinik_adi]" value="%s" class="regular-text" />', isset( $this->options['klinik_adi'] ) ? esc_attr( $this->options['klinik_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="kardiyolog_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="kardiyolog_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="kardiyolog_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="kardiyolog_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }

    public function hizmet_sayfalari_callback() {
        $selected_pages = isset($this->options['hizmet_sayfalari']) ? $this->options['hizmet_sayfalari'] : array();
        $pages = get_pages();
        
        if ($pages) {
            echo '<select name="kardiyolog_schema_options[hizmet_sayfalari][]" multiple="multiple" style="min-height: 150px;">';
            foreach ($pages as $page) {
                $selected = in_array($page->ID, $selected_pages) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select><p class="description">Uyguladığınız tedavilerin veya sunduğunuz hizmetlerin tanıtıldığı sayfaları seçin. (Birden çok seçim için CTRL/CMD tuşuna basılı tutun)</p>';
        } else {
            echo '<p>Sitenizde henüz sayfa bulunmuyor.</p>';
        }
    }
}
?>
