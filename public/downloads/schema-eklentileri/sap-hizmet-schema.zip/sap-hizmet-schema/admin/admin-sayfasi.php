<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package SAPHizmetSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class SAPHizmetSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('SAP Hizmet Schema Ayarları', 'SAP Hizmet Schema', 'manage_options', 'sap-hizmet-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'sap_hizmet_schema_options' );
        ?>
        <div class="wrap">
            <h1>SAP Hizmet Schema Ayarları</h1>
            <p>İşletmenizin ve hizmetlerinizin schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'sap_hizmet_schema_option_group' );
                do_settings_sections( 'sap-hizmet-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('sap_hizmet_schema_option_group', 'sap_hizmet_schema_options', array( $this, 'sanitize' ));

        // İşletme Bilgileri
        add_settings_section('setting_section_main', 'İşletme Bilgileri (ProfessionalService)', null, 'sap-hizmet-schema-admin');
        add_settings_field('isletme_adi', 'İşletme Adı', array( $this, 'isletme_adi_callback' ), 'sap-hizmet-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'sap-hizmet-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'sap-hizmet-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres', array( $this, 'adres_callback' ), 'sap-hizmet-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'İşletme Açıklaması', array( $this, 'aciklama_callback' ), 'sap-hizmet-schema-admin', 'setting_section_main');

        // Sayfa Seçimleri
        add_settings_section('setting_section_pages', 'Hizmet Sayfaları', null, 'sap-hizmet-schema-admin');
        add_settings_field('hizmet_sayfalari', 'Hizmet Sayfaları', array( $this, 'hizmet_sayfalari_callback' ), 'sap-hizmet-schema-admin', 'setting_section_pages');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['isletme_adi'] ) ) $new_input['isletme_adi'] = sanitize_text_field( $input['isletme_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );

        if ( isset( $input['hizmet_sayfalari'] ) && is_array( $input['hizmet_sayfalari'] ) ) {
            $new_input['hizmet_sayfalari'] = array_map( 'absint', $input['hizmet_sayfalari'] );
        }

        return $new_input;
    }

    // Callbacks
    public function isletme_adi_callback() { printf( '<input type="text" name="sap_hizmet_schema_options[isletme_adi]" value="%s" class="regular-text" />', isset( $this->options['isletme_adi'] ) ? esc_attr( $this->options['isletme_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="sap_hizmet_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="sap_hizmet_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="sap_hizmet_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="sap_hizmet_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }

    public function hizmet_sayfalari_callback() {
        $selected_pages = isset($this->options['hizmet_sayfalari']) ? $this->options['hizmet_sayfalari'] : array();
        $pages = get_pages();
        
        if ($pages) {
            echo '<select name="sap_hizmet_schema_options[hizmet_sayfalari][]" multiple="multiple" style="min-height: 150px;">';
            foreach ($pages as $page) {
                $selected = in_array($page->ID, $selected_pages) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select><p class="description">Sunduğunuz hizmetlerin tanıtıldığı sayfaları seçin. (Birden çok seçim için CTRL/CMD tuşuna basılı tutun)</p>';
        } else {
            echo '<p>Sitenizde henüz sayfa bulunmuyor.</p>';
        }
    }
}
?>
