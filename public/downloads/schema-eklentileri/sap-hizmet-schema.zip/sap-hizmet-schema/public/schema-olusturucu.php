<?php
/**
 * Sitenin ön yüzünde gerekli schema verilerini oluşturur ve <head> etiketine ekler.
 *
 * @package SAPHizmetSchema\Public
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class SAPHizmetSchemaPublic {

    private $options;

    public function __construct() {
        $this->options = get_option( 'sap_hizmet_schema_options' );
        add_action( 'wp_head', array( $this, 'inject_schema' ) );
    }

    public function inject_schema() {
        $schema = array();
        $current_id = get_the_ID();
        $hizmet_sayfalari = isset($this->options['hizmet_sayfalari']) ? $this->options['hizmet_sayfalari'] : array();

        if ( is_front_page() ) {
            $schema = $this->generate_homepage_schema();
        } elseif ( is_singular( 'post' ) ) {
            $schema = $this->generate_blog_schema();
        } elseif ( is_page() && in_array($current_id, $hizmet_sayfalari) ) {
            $schema = $this->generate_service_schema();
        }

        if ( ! empty( $schema ) ) {
            echo '<script type="application/ld+json">' . json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) . '</script>';
        }
    }

    private function generate_homepage_schema() {
        if ( empty( $this->options['isletme_adi'] ) ) {
            return array();
        }

        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'ProfessionalService',
            'name'        => $this->options['isletme_adi'],
            'url'         => get_home_url(),
            'telephone'   => isset( $this->options['telefon'] ) ? $this->options['telefon'] : '',
            'description' => isset( $this->options['aciklama'] ) ? $this->options['aciklama'] : get_bloginfo('description'),
            'serviceType' => 'SAP Danışmanlığı',
        );
        
        if ( ! empty( $this->options['logo_url'] ) ) $schema['image'] = $this->options['logo_url'];
        
        if ( ! empty( $this->options['adres'] ) ) {
            $schema['address'] = array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => $this->options['adres'],
            );
        }
        
        return $schema;
    }
    
    private function generate_blog_schema() {
        global $post;
        if ( empty( $this->options['isletme_adi'] ) ) return array();
        
        $schema = array(
            '@context'       => 'https://schema.org',
            '@type'          => 'BlogPosting',
            'mainEntityOfPage' => array('@type' => 'WebPage', '@id' => get_permalink()),
            'headline'       => get_the_title(),
            'datePublished'  => get_the_date('c'),
            'dateModified'   => get_the_modified_date('c'),
            'author'         => array('@type' => 'Person', 'name' => get_the_author()),
            'publisher'      => array(
                '@type' => 'Organization',
                'name'  => $this->options['isletme_adi'],
                'logo'  => array('@type' => 'ImageObject', 'url'   => isset($this->options['logo_url']) ? $this->options['logo_url'] : ''),
            ),
            'description'    => get_the_excerpt(),
        );
        if ( has_post_thumbnail() ) $schema['image'] = get_the_post_thumbnail_url();
        return $schema;
    }
    
    private function generate_service_schema() {
        global $post;
        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Service',
            'name'        => get_the_title(),
            'url'         => get_permalink(),
            'description' => get_the_excerpt(),
            'provider'    => array(
                '@type' => 'ProfessionalService',
                'name' => isset($this->options['isletme_adi']) ? $this->options['isletme_adi'] : '',
            )
        );

        if ( ! empty( $this->options['adres'] ) ) {
            $schema['provider']['address'] = array(
                '@type'           => 'PostalAddress',
                'streetAddress'   => $this->options['adres'],
            );
        }

        if ( has_post_thumbnail() ) $schema['image'] = get_the_post_thumbnail_url();
        
        return $schema;
    }
}
?>
