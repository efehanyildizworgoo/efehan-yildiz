<?php
/**
 * Plugin Name:       SAP Hizmet Schema Eklentisi
 * Description:       SAP danışmanlığı gibi profesyonel hizmetler sunan siteler için ProfessionalService schemasını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sap-hizmet-schema
 *
 * @package           SAPHizmetSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'SAP_HIZMET_SCHEMA_VERSION', '1.0.0' );
define( 'SAP_HIZMET_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once SAP_HIZMET_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once SAP_HIZMET_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'SAPHizmetSchemaAdmin' ) ) {
    new SAPHizmetSchemaAdmin();
}

if ( class_exists( 'SAPHizmetSchemaPublic' ) ) {
    new SAPHizmetSchemaPublic();
}
?>
