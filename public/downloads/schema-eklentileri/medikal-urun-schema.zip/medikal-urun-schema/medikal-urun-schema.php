<?php
/**
 * Plugin Name:       Medikal Ürün Schema Eklentisi
 * Description:       Hasta yatağı, masaj koltuğu gibi medikal ürünler satan siteler için MedicalDeviceStore schemasını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       medikal-urun-schema
 *
 * @package           MedikalUrunSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'MEDIKAL_URUN_SCHEMA_VERSION', '1.0.0' );
define( 'MEDIKAL_URUN_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once MEDIKAL_URUN_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once MEDIKAL_URUN_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'MedikalUrunSchemaAdmin' ) ) {
    new MedikalUrunSchemaAdmin();
}

if ( class_exists( 'MedikalUrunSchemaPublic' ) ) {
    new MedikalUrunSchemaPublic();
}
?>
