<?php
/**
 * Plugin Name:       Ayakkabı Dükkanı Schema Eklentisi
 * Description:       Ayakkabı satışı yapan e-ticaret siteleri için ShoeStore schema yapısını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://wwww.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ayakkabi-dukkani-schema
 *
 * @package           AyakkabiDukkaniSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'AYAKKABI_DUKKANI_SCHEMA_VERSION', '1.0.0' );
define( 'AYAKKABI_DUKKANI_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once AYAKKABI_DUKKANI_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once AYAKKABI_DUKKANI_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'AyakkabiDukkaniSchemaAdmin' ) ) {
    new AyakkabiDukkaniSchemaAdmin();
}

if ( class_exists( 'AyakkabiDukkaniSchemaPublic' ) ) {
    new AyakkabiDukkaniSchemaPublic();
}
?>