<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package AyakkabiDukkaniSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class AyakkabiDukkaniSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('Ayakkabı Dükkanı Schema Ayarları', 'Ayakkabı Dükkanı Schema', 'manage_options', 'ayakkabi-dukkani-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'ayakkabi_dukkani_schema_options' );
        ?>
        <div class="wrap">
            <h1>Ayakkabı Dükkanı Schema Ayarları</h1>
            <p>Mağazanız için schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'ayakkabi_dukkani_schema_option_group' );
                do_settings_sections( 'ayakkabi-dukkani-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('ayakkabi_dukkani_schema_option_group', 'ayakkabi_dukkani_schema_options', array( $this, 'sanitize' ));

        // Mağaza Bilgileri
        add_settings_section('setting_section_main', 'Mağaza Bilgileri (ShoeStore)', null, 'ayakkabi-dukkani-schema-admin');
        add_settings_field('magaza_adi', 'Mağaza Adı', array( $this, 'magaza_adi_callback' ), 'ayakkabi-dukkani-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'ayakkabi-dukkani-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'ayakkabi-dukkani-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres (Fiziksel mağaza varsa)', array( $this, 'adres_callback' ), 'ayakkabi-dukkani-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'Mağaza Açıklaması', array( $this, 'aciklama_callback' ), 'ayakkabi-dukkani-schema-admin', 'setting_section_main');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['magaza_adi'] ) ) $new_input['magaza_adi'] = sanitize_text_field( $input['magaza_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );

        return $new_input;
    }

    // Callbacks
    public function magaza_adi_callback() { printf( '<input type="text" name="ayakkabi_dukkani_schema_options[magaza_adi]" value="%s" class="regular-text" />', isset( $this->options['magaza_adi'] ) ? esc_attr( $this->options['magaza_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="ayakkabi_dukkani_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="ayakkabi_dukkani_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="ayakkabi_dukkani_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="ayakkabi_dukkani_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }
    
}
?>
