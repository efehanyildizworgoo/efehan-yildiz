<?php
/**
 * Plugin Name:       Güzellik Merkezi Schema Eklentisi
 * Description:       Güzellik merkezi gibi yerel işletmeler için özelleştirilmiş Schema.org JSON-LD yapılarını WordPress sitelerine entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       guzellik-merkezi-schema
 *
 * @package           GuzellikMerkeziSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'GUZELLIK_MERKEZI_SCHEMA_VERSION', '1.0.0' );
define( 'GUZELLIK_MERKEZI_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once GUZELLIK_MERKEZI_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once GUZELLIK_MERKEZI_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'GuzellikMerkeziSchemaAdmin' ) ) {
    new GuzellikMerkeziSchemaAdmin();
}

if ( class_exists( 'GuzellikMerkeziSchemaPublic' ) ) {
    new GuzellikMerkeziSchemaPublic();
}
?>
