<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package GuzellikMerkeziSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class GuzellikMerkeziSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('Güzellik Merkezi Schema Ayarları', 'Güzellik Merkezi Schema', 'manage_options', 'guzellik-merkezi-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'guzellik_merkezi_schema_options' );
        ?>
        <div class="wrap">
            <h1>Güzellik Merkezi Schema Ayarları</h1>
            <p>Güzellik merkeziniz için schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'guzellik_merkezi_schema_option_group' );
                do_settings_sections( 'guzellik-merkezi-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('guzellik_merkezi_schema_option_group', 'guzellik_merkezi_schema_options', array( $this, 'sanitize' ));

        // Merkez Bilgileri
        add_settings_section('setting_section_main', 'Merkez Bilgileri (BeautySalon)', null, 'guzellik-merkezi-schema-admin');
        add_settings_field('merkez_adi', 'Merkez Adı', array( $this, 'merkez_adi_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres', array( $this, 'adres_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        add_settings_field('hizmet_bolgesi', 'Hizmet Bölgesi', array( $this, 'hizmet_bolgesi_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'Merkez Açıklaması', array( $this, 'aciklama_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_main');
        
        // Sayfa Seçimleri
        add_settings_section('setting_section_pages', 'Sayfa Türleri', null, 'guzellik-merkezi-schema-admin');
        add_settings_field('hizmet_sayfalari', 'Hizmet Sayfaları', array( $this, 'hizmet_sayfalari_callback' ), 'guzellik-merkezi-schema-admin', 'setting_section_pages');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['merkez_adi'] ) ) $new_input['merkez_adi'] = sanitize_text_field( $input['merkez_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['hizmet_bolgesi'] ) ) $new_input['hizmet_bolgesi'] = sanitize_text_field( $input['hizmet_bolgesi'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );

        if ( isset( $input['hizmet_sayfalari'] ) ) {
            $new_input['hizmet_sayfalari'] = array_map( 'absint', (array) $input['hizmet_sayfalari'] );
        }

        return $new_input;
    }

    // Callbacks
    public function merkez_adi_callback() { printf( '<input type="text" name="guzellik_merkezi_schema_options[merkez_adi]" value="%s" class="regular-text" />', isset( $this->options['merkez_adi'] ) ? esc_attr( $this->options['merkez_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="guzellik_merkezi_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="guzellik_merkezi_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function hizmet_bolgesi_callback() { printf( '<input type="text" name="guzellik_merkezi_schema_options[hizmet_bolgesi]" value="%s" placeholder="Örn: İstanbul" class="regular-text"/><p class="description">Hizmet verdiğiniz şehir veya ilçe.</p>', isset( $this->options['hizmet_bolgesi'] ) ? esc_attr( $this->options['hizmet_bolgesi'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="guzellik_merkezi_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="guzellik_merkezi_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }
    
    public function hizmet_sayfalari_callback() {
        $selected_pages = isset($this->options['hizmet_sayfalari']) ? (array) $this->options['hizmet_sayfalari'] : [];
        $pages = get_pages();
        
        if ($pages) {
            echo '<select name="guzellik_merkezi_schema_options[hizmet_sayfalari][]" multiple="multiple" style="min-height: 150px; min-width: 300px;">';
            foreach ($pages as $page) {
                $selected = in_array($page->ID, $selected_pages) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select><p class="description">Hizmetlerinizi (lazer epilasyon, cilt bakımı vb.) anlattığınız sayfaları seçin.</p>';
        } else {
            echo '<p>Sitenizde henüz sayfa bulunmuyor.</p>';
        }
    }
}
?>
