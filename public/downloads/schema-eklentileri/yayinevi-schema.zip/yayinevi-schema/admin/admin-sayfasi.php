<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package YayineviSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class YayineviSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('Yayınevi Schema Ayarları', 'Yayınevi Schema', 'manage_options', 'yayinevi-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'yayinevi_schema_options' );
        ?>
        <div class="wrap">
            <h1>Yayınevi Schema Ayarları</h1>
            <p>Yayıneviniz ve hizmetleriniz için schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'yayinevi_schema_option_group' );
                do_settings_sections( 'yayinevi-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('yayinevi_schema_option_group', 'yayinevi_schema_options', array( $this, 'sanitize' ));

        // Yayınevi Bilgileri
        add_settings_section('setting_section_main', 'Yayınevi Bilgileri (Publisher)', null, 'yayinevi-schema-admin');
        add_settings_field('yayinevi_adi', 'Yayınevi Adı', array( $this, 'yayinevi_adi_callback' ), 'yayinevi-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'yayinevi-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'yayinevi-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres', array( $this, 'adres_callback' ), 'yayinevi-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'Yayınevi Açıklaması', array( $this, 'aciklama_callback' ), 'yayinevi-schema-admin', 'setting_section_main');
        
        // Sayfa Seçimleri
        add_settings_section('setting_section_pages', 'Özel Sayfa Türleri', null, 'yayinevi-schema-admin');
        add_settings_field('yayinlatma_sayfasi', 'Kitap Yayınlatma Sayfası', array( $this, 'yayinlatma_sayfasi_callback' ), 'yayinevi-schema-admin', 'setting_section_pages');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['yayinevi_adi'] ) ) $new_input['yayinevi_adi'] = sanitize_text_field( $input['yayinevi_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );
        if ( isset( $input['yayinlatma_sayfasi'] ) ) $new_input['yayinlatma_sayfasi'] = absint( $input['yayinlatma_sayfasi'] );

        return $new_input;
    }

    // Callbacks
    public function yayinevi_adi_callback() { printf( '<input type="text" name="yayinevi_schema_options[yayinevi_adi]" value="%s" class="regular-text" />', isset( $this->options['yayinevi_adi'] ) ? esc_attr( $this->options['yayinevi_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="yayinevi_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="yayinevi_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="yayinevi_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="yayinevi_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }
    
    public function yayinlatma_sayfasi_callback() {
        $selected_page = isset($this->options['yayinlatma_sayfasi']) ? $this->options['yayinlatma_sayfasi'] : 0;
        $pages = get_pages();
        
        if ($pages) {
            echo '<select name="yayinevi_schema_options[yayinlatma_sayfasi]">';
            echo '<option value="0">— Sayfa Seçin —</option>';
            foreach ($pages as $page) {
                $selected = selected($selected_page, $page->ID, false);
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select><p class="description">Yazarlara kitap yayınlatma hizmetini anlattığınız sayfayı seçin.</p>';
        } else {
            echo '<p>Sitenizde henüz sayfa bulunmuyor.</p>';
        }
    }
}
?>
