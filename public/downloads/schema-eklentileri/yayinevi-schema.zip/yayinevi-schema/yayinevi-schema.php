<?php
/**
 * Plugin Name:       Yayınevi ve Kitap Satış Schema Eklentisi
 * Description:       Yayınevi ve kitap satışı yapan siteler için Publisher ve Service schemalarını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       yayinevi-schema
 *
 * @package           YayineviSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'YAYINEVI_SCHEMA_VERSION', '1.0.0' );
define( 'YAYINEVI_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once YAYINEVI_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once YAYINEVI_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'YayineviSchemaAdmin' ) ) {
    new YayineviSchemaAdmin();
}

if ( class_exists( 'YayineviSchemaPublic' ) ) {
    new YayineviSchemaPublic();
}
?>
