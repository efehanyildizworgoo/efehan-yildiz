<?php
/**
 * Plugin Name:       Kombi Servis Schema Eklentisi
 * Description:       Kombi servisi gibi yerel işletmeler için özelleştirilmiş Schema.org JSON-LD yapılarını WordPress sitelerine entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kombi-servis-schema
 *
 * @package           KombiServisSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'KOMBI_SERVIS_SCHEMA_VERSION', '1.0.0' );
define( 'KOMBI_SERVIS_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once KOMBI_SERVIS_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once KOMBI_SERVIS_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'KombiServisSchemaAdmin' ) ) {
    new KombiServisSchemaAdmin();
}

if ( class_exists( 'KombiServisSchemaPublic' ) ) {
    new KombiServisSchemaPublic();
}
?>
