<?php
/**
 * Plugin Name:       Bungalov Kiralama Schema Eklentisi
 * Description:       Bungalov ve villa kiralama siteleri için LodgingBusiness ve VacationRental schemalarını entegre eder.
 * Version:           1.0.0
 * Author:            Worgoo
 * Author URI:        https://www.worgoo.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bungalov-kiralama-schema
 *
 * @package           BungalovKiralamaSchema
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

// Plugin constants
define( 'BUNGALOV_KIRALAMA_SCHEMA_VERSION', '1.0.0' );
define( 'BUNGALOV_KIRALAMA_SCHEMA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

// Admin menüsünü ve ayarlarını yükle
require_once BUNGALOV_KIRALAMA_SCHEMA_PLUGIN_DIR . 'admin/admin-sayfasi.php';

// Ön yüz schema oluşturucusunu yükle
require_once BUNGALOV_KIRALAMA_SCHEMA_PLUGIN_DIR . 'public/schema-olusturucu.php';

// Eklenti sınıflarını başlat
if ( class_exists( 'BungalovKiralamaSchemaAdmin' ) ) {
    new BungalovKiralamaSchemaAdmin();
}

if ( class_exists( 'BungalovKiralamaSchemaPublic' ) ) {
    new BungalovKiralamaSchemaPublic();
}
?>
