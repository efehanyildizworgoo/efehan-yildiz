<?php
/**
 * Eklentinin admin panelindeki ayarlar sayfasını yönetir.
 *
 * @package BungalovKiralamaSchema\Admin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Direct access not allowed.
}

class BungalovKiralamaSchemaAdmin {

    private $options;

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    public function add_plugin_page() {
        add_options_page('Bungalov Kiralama Schema', 'Bungalov Schema', 'manage_options', 'bungalov-kiralama-schema-ayarlari', array( $this, 'create_admin_page' ));
    }

    public function create_admin_page() {
        $this->options = get_option( 'bungalov_kiralama_schema_options' );
        ?>
        <div class="wrap">
            <h1>Bungalov Kiralama Schema Ayarları</h1>
            <p>İşletmeniz ve kiralık birimleriniz için schema bilgilerini bu sayfadan yönetebilirsiniz.</p>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'bungalov_kiralama_schema_option_group' );
                do_settings_sections( 'bungalov-kiralama-schema-admin' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function page_init() {
        register_setting('bungalov_kiralama_schema_option_group', 'bungalov_kiralama_schema_options', array( $this, 'sanitize' ));

        // İşletme Bilgileri
        add_settings_section('setting_section_main', 'İşletme Bilgileri (LodgingBusiness)', null, 'bungalov-kiralama-schema-admin');
        add_settings_field('isletme_adi', 'İşletme Adı', array( $this, 'isletme_adi_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        add_settings_field('telefon', 'Telefon', array( $this, 'telefon_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        add_settings_field('logo_url', 'Logo URL', array( $this, 'logo_url_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        add_settings_field('adres', 'Açık Adres', array( $this, 'adres_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        add_settings_field('aciklama', 'İşletme Açıklaması', array( $this, 'aciklama_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        add_settings_field('fiyat_araligi', 'Fiyat Aralığı', array( $this, 'fiyat_araligi_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_main');
        
        // Sayfa Seçimleri
        add_settings_section('setting_section_pages', 'Kiralık Birim Sayfaları (VacationRental)', null, 'bungalov-kiralama-schema-admin');
        add_settings_field('kiralik_birim_sayfalari', 'Bungalov / Villa Sayfaları', array( $this, 'kiralik_birim_sayfalari_callback' ), 'bungalov-kiralama-schema-admin', 'setting_section_pages');
    }
    
    public function sanitize( $input ) {
        $new_input = array();
        if ( isset( $input['isletme_adi'] ) ) $new_input['isletme_adi'] = sanitize_text_field( $input['isletme_adi'] );
        if ( isset( $input['telefon'] ) ) $new_input['telefon'] = sanitize_text_field( $input['telefon'] );
        if ( isset( $input['logo_url'] ) ) $new_input['logo_url'] = esc_url_raw( $input['logo_url'] );
        if ( isset( $input['adres'] ) ) $new_input['adres'] = sanitize_textarea_field( $input['adres'] );
        if ( isset( $input['aciklama'] ) ) $new_input['aciklama'] = sanitize_textarea_field( $input['aciklama'] );
        if ( isset( $input['fiyat_araligi'] ) ) $new_input['fiyat_araligi'] = sanitize_text_field( $input['fiyat_araligi'] );

        if ( isset( $input['kiralik_birim_sayfalari'] ) && is_array( $input['kiralik_birim_sayfalari'] ) ) {
            $new_input['kiralik_birim_sayfalari'] = array_map( 'absint', $input['kiralik_birim_sayfalari'] );
        }

        return $new_input;
    }

    // Callbacks
    public function isletme_adi_callback() { printf( '<input type="text" name="bungalov_kiralama_schema_options[isletme_adi]" value="%s" class="regular-text" />', isset( $this->options['isletme_adi'] ) ? esc_attr( $this->options['isletme_adi'] ) : '' ); }
    public function telefon_callback() { printf( '<input type="text" name="bungalov_kiralama_schema_options[telefon]" value="%s" class="regular-text"/>', isset( $this->options['telefon'] ) ? esc_attr( $this->options['telefon'] ) : '' ); }
    public function logo_url_callback() { printf( '<input type="url" name="bungalov_kiralama_schema_options[logo_url]" value="%s" class="regular-text" />', isset( $this->options['logo_url'] ) ? esc_attr( $this->options['logo_url'] ) : '' ); }
    public function adres_callback() { printf( '<textarea name="bungalov_kiralama_schema_options[adres]" rows="4" class="large-text">%s</textarea>', isset( $this->options['adres'] ) ? esc_textarea( $this->options['adres'] ) : '' ); }
    public function aciklama_callback() { printf( '<textarea name="bungalov_kiralama_schema_options[aciklama]" rows="4" class="large-text">%s</textarea>', isset( $this->options['aciklama'] ) ? esc_textarea( $this->options['aciklama'] ) : '' ); }
    public function fiyat_araligi_callback() { printf( '<input type="text" name="bungalov_kiralama_schema_options[fiyat_araligi]" value="%s" placeholder="Örn: ₺₺₺ veya 1500TL - 5000TL" class="regular-text"/>', isset( $this->options['fiyat_araligi'] ) ? esc_attr( $this->options['fiyat_araligi'] ) : '' ); }

    public function kiralik_birim_sayfalari_callback() {
        $selected_pages = isset($this->options['kiralik_birim_sayfalari']) ? $this->options['kiralik_birim_sayfalari'] : array();
        $pages = get_pages();
        
        if ($pages) {
            echo '<select name="bungalov_kiralama_schema_options[kiralik_birim_sayfalari][]" multiple="multiple" style="min-height: 150px;">';
            foreach ($pages as $page) {
                $selected = in_array($page->ID, $selected_pages) ? 'selected="selected"' : '';
                echo '<option value="' . esc_attr($page->ID) . '" ' . $selected . '>' . esc_html($page->post_title) . '</option>';
            }
            echo '</select><p class="description">Her bir bungalov veya villanın tanıtıldığı sayfaları seçin. (Birden çok seçim için CTRL/CMD tuşuna basılı tutun)</p>';
        } else {
            echo '<p>Sitenizde henüz sayfa bulunmuyor.</p>';
        }
    }
}
?>
