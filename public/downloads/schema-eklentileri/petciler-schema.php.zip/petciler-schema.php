<?php
/**
 * Plugin Name: Petciler SEO Schema Manager
 * Description: Petciler.com için özel JSON-LD Schema işaretlemeleri (Anasayfa, Kategori, İlan Detay).
 * Version: 1.0
 * Author: Petciler Dev Team
 * Author URI: https://petciler.com
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Doğrudan erişimi engelle
}

class Petciler_Schema_Markup {

    public function __construct() {
        add_action( 'wp_head', array( $this, 'output_json_ld' ) );
    }

    public function output_json_ld() {
        $schema = array();

        // 1. ANASAYFA SCHEMA (Verdiğiniz Yapı)
        if ( is_front_page() ) {
            $schema = $this->get_homepage_schema();
        } 
        // 2. KATEGORİ / ARŞİV SCHEMA
        elseif ( is_category() || is_tag() || is_tax() ) {
            $schema = $this->get_archive_schema();
        } 
        // 3. İLAN DETAY (SINGLE) SCHEMA
        elseif ( is_singular() ) {
            $schema = $this->get_single_listing_schema();
        }

        if ( ! empty( $schema ) ) {
            echo '' . "\n";
            echo '<script type="application/ld+json">' . "\n";
            echo json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) . "\n";
            echo '</script>' . "\n";
            echo '' . "\n";
        }
    }

    /**
     * ANASAYFA İÇİN SCHEMA YAPISI
     */
    private function get_homepage_schema() {
        $site_url = home_url();
        $site_name = get_bloginfo( 'name' );
        $logo_url = 'https://petciler.com/petciler-logosu.webp'; // Burayı dinamik de yapabilirsiniz

        // Öne çıkan son 3 ilanı çekelim (Dinamik ItemList)
        $latest_posts = get_posts( array(
            'numberposts' => 3,
            'post_status' => 'publish',
        ));

        $item_list_element = array();
        $position = 1;

        foreach ( $latest_posts as $post ) {
            $item_list_element[] = array(
                "@type" => "ListItem",
                "position" => $position,
                "url" => get_permalink($post->ID),
                "name" => $post->post_title
            );
            $position++;
        }

        return array(
            "@context" => "https://schema.org",
            "@graph" => array(
                array(
                    "@type" => "Organization",
                    "@id" => $site_url . "/#organization",
                    "name" => "Petciler",
                    "url" => $site_url,
                    "logo" => $logo_url,
                    "sameAs" => array(
                        "https://www.instagram.com/petciler", // Varsa sosyal medya linkleri
                        "https://www.facebook.com/petciler"
                    ),
                    "description" => "Türkiye genelinde köpek, kedi, kuş ve diğer evcil hayvanlar için sahiplendirme ilanları sunan çevrimiçi platform.",
                    "areaServed" => array(
                        "@type" => "Country",
                        "name" => "Türkiye"
                    )
                ),
                array(
                    "@type" => "WebSite",
                    "@id" => $site_url . "/#website",
                    "url" => $site_url,
                    "name" => $site_name,
                    "publisher" => array(
                        "@id" => $site_url . "/#organization"
                    ),
                    "inLanguage" => "tr-TR",
                    "potentialAction" => array(
                        "@type" => "SearchAction",
                        "target" => $site_url . "/?s={search_term_string}",
                        "query-input" => "required name=search_term_string"
                    )
                ),
                array(
                    "@type" => ["WebPage", "CollectionPage"],
                    "@id" => $site_url . "/#webpage",
                    "url" => $site_url,
                    "name" => "Evcil Hayvan İlanları Köpek ve Kedi Sahiplendirme | Petciler",
                    "description" => get_bloginfo('description'),
                    "inLanguage" => "tr-TR",
                    "isPartOf" => array(
                        "@id" => $site_url . "/#website"
                    ),
                    "about" => array(
                        array("@type" => "Thing", "name" => "Toy Poodle sahiplenme"),
                        array("@type" => "Thing", "name" => "British Shorthair sahiplenme"),
                        array("@type" => "Thing", "name" => "Pomeranian Boo sahiplenme"),
                        array("@type" => "Thing", "name" => "Maltipoo sahiplenme")
                    ),
                    "mainEntity" => array(
                        "@type" => "ItemList",
                        "name" => "Öne Çıkan Evcil Hayvan Sahiplendirme İlanları",
                        "itemListOrder" => "https://schema.org/ItemListOrderDescending",
                        "itemListElement" => $item_list_element
                    )
                )
            )
        );
    }

    /**
     * KATEGORİ / ARŞİV SAYFALARI İÇİN SCHEMA
     */
    private function get_archive_schema() {
        global $wp_query;
        
        $term = get_queried_object();
        $site_url = home_url();
        $current_url = get_term_link($term);

        // O anki sayfadaki ilanları listeye ekle
        $item_list_element = array();
        $position = 1;

        if ( have_posts() ) {
            while ( have_posts() ) {
                the_post();
                $item_list_element[] = array(
                    "@type" => "ListItem",
                    "position" => $position,
                    "url" => get_permalink(),
                    "name" => get_the_title()
                );
                $position++;
            }
        }

        return array(
            "@context" => "https://schema.org",
            "@type" => "CollectionPage",
            "name" => $term->name . " İlanları | Petciler",
            "description" => $term->description ? $term->description : $term->name . " kategorisindeki en güncel sahiplendirme ilanları.",
            "url" => $current_url,
            "mainEntity" => array(
                "@type" => "ItemList",
                "itemListElement" => $item_list_element
            ),
            "breadcrumb" => array(
                "@type" => "BreadcrumbList",
                "itemListElement" => array(
                    array(
                        "@type" => "ListItem",
                        "position" => 1,
                        "name" => "Anasayfa",
                        "item" => $site_url
                    ),
                    array(
                        "@type" => "ListItem",
                        "position" => 2,
                        "name" => $term->name,
                        "item" => $current_url
                    )
                )
            )
        );
    }

    /**
     * İLAN DETAY (SINGLE) SAYFASI İÇİN SCHEMA
     */
    private function get_single_listing_schema() {
        global $post;
        $site_url = home_url();
        $post_url = get_permalink();
        $featured_img_url = get_the_post_thumbnail_url( $post->ID, 'full' );

        // Fiyat varsa al, yoksa 0 (Sahiplendirme olduğu için genelde semboliktir)
        // Eğer özel alan kullanıyorsanız 'price' kısmını get_post_meta() ile çekin.
        $price = "0"; 
        $currency = "TRY";
        
        // Kategorileri çek
        $categories = get_the_category();
        $category_name = !empty($categories) ? $categories[0]->name : 'Genel';

        return array(
            "@context" => "https://schema.org",
            "@graph" => array(
                // 1. Breadcrumb
                array(
                    "@type" => "BreadcrumbList",
                    "itemListElement" => array(
                        array(
                            "@type" => "ListItem",
                            "position" => 1,
                            "name" => "Anasayfa",
                            "item" => $site_url
                        ),
                        array(
                            "@type" => "ListItem",
                            "position" => 2,
                            "name" => $category_name,
                            "item" => $site_url . '/' . (!empty($categories) ? $categories[0]->slug : '')
                        ),
                        array(
                            "@type" => "ListItem",
                            "position" => 3,
                            "name" => get_the_title(),
                            "item" => $post_url
                        )
                    )
                ),
                // 2. Product (İlanın kendisi)
                // Evcil hayvan ilanları için 'Product' kullanımı Google tarafından en çok desteklenen yapıdır.
                // Alternatif olarak daha spesifik 'Dog' veya 'Cat' kullanılabilir ancak Product daha güvenlidir.
                array(
                    "@type" => "Product",
                    "name" => get_the_title(),
                    "image" => $featured_img_url ? $featured_img_url : $site_url . '/default-pet.jpg',
                    "description" => wp_strip_all_tags( get_the_excerpt() ), // Kısa açıklama
                    "sku" => "PET-" . $post->ID,
                    "brand" => array(
                        "@type" => "Brand",
                        "name" => "Petciler" // Veya hayvanın cinsi
                    ),
                    "offers" => array(
                        "@type" => "Offer",
                        "url" => $post_url,
                        "priceCurrency" => $currency,
                        "price" => $price,
                        "availability" => "https://schema.org/InStock",
                        "itemCondition" => "https://schema.org/NewCondition"
                    )
                )
            )
        );
    }
}

new Petciler_Schema_Markup();